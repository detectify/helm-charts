# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.3.0] - 2026-03-09

### Fixed

- Use correct image tag for Chrome Container

### Removed

- Unused option
- Removed `config.scannerNamespace` (use `namespace.name` instead)

## [1.2.0] - 2026-03-05

### Fixed

- Simplify setup by setting working default values for:
  - `registry.server`
  - `registry.imagePullSecrets`
  - `images.*.tag`
- Adjust resource requirements.
- Changed default `minReplicas` to `1` for `scanScheduler`.

### Removed

- Removed Prometheus and related options

## [1.1.0] - 2026-02-17

### Added
- Redis persistence with PVC, volumeMounts, and `redis.deploy` toggle
- `Recreate` deployment strategy for Redis when persistence is enabled (prevents RWO PVC deadlock)
- `wait-for-redis` init containers on scan-scheduler and scan-manager
- PriorityClass for redis and scan-scheduler to protect critical components under resource pressure

### Fixed
- Autoscaling config keys not applied to Helm chart

## [1.0.0] - 2025-02-03

### Added
- Initial release of Detectify Internal Scanning Helm Chart
- scan-scheduler: API entry point, license validation, job queuing
- scan-manager: Job orchestration, scan-worker pod management
- scan-worker: Ephemeral pods for security scanning
- chrome-controller: Browser instance management
- Redis: Persistent job queue with optional external Redis support
- Horizontal Pod Autoscaling (HPA) for scan-scheduler and scan-manager
- Prometheus metrics and Pushgateway integration
- Configurable resource limits and requests
- Support for Kubernetes 1.24+

[Unreleased]: https://github.com/detectify/helm-charts/compare/v1.1.0...HEAD
[1.1.0]: https://github.com/detectify/helm-charts/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/detectify/helm-charts/releases/tag/v1.0.0
