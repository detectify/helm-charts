# Detectify Internal Scanning Agent

Helm chart for deploying [Detectify Internal Scanning Agent](https://detectify.com/product/internal-scanning) to your Kubernetes cluster.

## Quick Start

```bash
# Add the Detectify Helm repository
helm repo add detectify https://detectify.github.io/helm-charts
helm repo update

# Create a values file with your credentials
cat > my-values.yaml <<EOF
secrets:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
  registry:
    username: "your-registry-username"
    password: "your-registry-password"
EOF

# Install the chart (namespace comes from -n / --create-namespace)
helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace

# Verify the deployment
kubectl get pods -n scanner
```

## Prerequisites

- Kubernetes 1.29+
- Helm 3.8+
- Detectify license credentials (contact [Detectify Sales](https://detectify.com/contact))
- PersistentVolume provisioner (for Redis storage)

### Network Requirements

The scanner requires outbound HTTPS (443) access to:

| Endpoint | Purpose |
|----------|---------|
| `registry.detectify.com` | Pull container images |
| `license.detectify.com` | License validation |
| `connector.detectify.com` | Scan coordination with Detectify platform |

Ensure these endpoints are accessible from your cluster. No inbound connections are required unless you enable ingress for the API.

## Components

| Component | Description |
|-----------|-------------|
| **Scan Scheduler** | API endpoint for triggering scans, validates licenses, queues jobs |
| **Scan Manager** | Orchestrates scan execution, creates ephemeral scan-worker pods |
| **Scan Worker** | Ephemeral pods that execute security tests against targets |
| **Chrome Controller** | Manages pool of headless Chrome instances for JavaScript analysis |
| **Redis** | Persistent queue for scan jobs and state management |

## Installation

### From Helm Repository (Recommended)

```bash
helm repo add detectify https://detectify.github.io/helm-charts
helm repo update

helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace
```

## Configuration

### Secrets: two modes

The chart needs two Secrets to run: a **config Secret** (license key, connector API key) and a **registry Secret** (Docker credentials for pulling scanner images). You have two ways to provide each, and they're independent — you can mix and match.

| Mode | How | When to use |
|------|-----|-------------|
| **Chart-managed** (default) | Put the credentials in your Helm values under `secrets.*`; the chart renders the Secret for you. | Development, quick evaluations, or when keeping credentials in Helm values / Terraform is acceptable to your security team. |
| **Bring-your-own** | Create the Secret yourself (via any tool), then set `secrets.existingConfigSecret` / `secrets.existingRegistrySecret` to its name. | Production setups where secrets must live outside Helm — Vault, external-secrets-operator, sealed-secrets, AWS Secrets Manager, CSI Secret Store driver, hand-managed `kubernetes_secret` Terraform resource, etc. |

The two `existing*Secret` fields are independent. Common setups:

- **Both chart-managed** — simplest; equivalent to the 1.x behavior.
- **Both BYO** — everything flows through your secrets platform.
- **Chart-managed config + BYO registry** — for example, when registry creds live in Vault but the license key is fine in Terraform.
- **BYO config + chart-managed registry** — the mirror case.

### Required Values (chart-managed mode)

All sensitive values live under a single `secrets:` block:

```yaml
secrets:
  licenseKey: "your-license-key"             # Provided by Detectify
  connectorApiKey: "your-connector-api-key"  # Provided by Detectify
  registry:
    username: "your-registry-username"       # Provided by Detectify
    password: "your-registry-password"       # Provided by Detectify
```

### Bring-your-own Secret

Point the chart at pre-existing Kubernetes Secrets by name:

```yaml
secrets:
  existingConfigSecret: "my-team-scanner-config"
  existingRegistrySecret: "my-team-detectify-registry"
```

When either of these is set, the chart does **not** render the corresponding chart-managed Secret and the pods read directly from the named Secret. The Secret must exist in the release namespace before `helm install` / `helm upgrade`; otherwise the pods will crashloop on startup.

You can set just one of them — e.g. only `existingRegistrySecret` — and fall back to the chart-managed path for the other by populating the inline `secrets.*` fields.

#### Expected Secret schemas

| Secret | Type | Keys |
|--------|------|------|
| `existingConfigSecret` | `Opaque` | `license-key`, `connector-api-key`, `connector-url` |
| `existingRegistrySecret` | `kubernetes.io/dockerconfigjson` | `.dockerconfigjson` |

`connector-url` should match `config.connectorServerUrl` (default `https://connector.detectify.com`).

#### Option 1: create the Secrets with `kubectl`

```bash
kubectl create namespace scanner

# Config Secret
kubectl create secret generic my-team-scanner-config \
  -n scanner \
  --from-literal=license-key="your-license-key" \
  --from-literal=connector-api-key="your-connector-api-key" \
  --from-literal=connector-url="https://connector.detectify.com"

# Registry Secret
kubectl create secret docker-registry my-team-detectify-registry \
  -n scanner \
  --docker-server=registry.detectify.com \
  --docker-username="your-registry-username" \
  --docker-password="your-registry-password"
```

Then install the chart:

```bash
helm install scanner detectify/internal-scanning-agent \
  -n scanner \
  --set secrets.existingConfigSecret=my-team-scanner-config \
  --set secrets.existingRegistrySecret=my-team-detectify-registry
```

#### Option 2: external-secrets-operator (sync from Vault / AWS SM / etc.)

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: my-team-scanner-config
  namespace: scanner
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: my-store
    kind: ClusterSecretStore
  target:
    name: my-team-scanner-config        # matches secrets.existingConfigSecret
    creationPolicy: Owner
  data:
    - secretKey: license-key
      remoteRef: { key: detectify/scanner, property: licenseKey }
    - secretKey: connector-api-key
      remoteRef: { key: detectify/scanner, property: connectorApiKey }
    - secretKey: connector-url
      remoteRef: { key: detectify/scanner, property: connectorUrl }
---
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: my-team-detectify-registry
  namespace: scanner
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: my-store
    kind: ClusterSecretStore
  target:
    name: my-team-detectify-registry    # matches secrets.existingRegistrySecret
    creationPolicy: Owner
    template:
      type: kubernetes.io/dockerconfigjson
      data:
        .dockerconfigjson: |
          {"auths":{"registry.detectify.com":{"username":"{{ .username }}","password":"{{ .password }}","auth":"{{ printf "%s:%s" .username .password | b64enc }}"}}}
  data:
    - secretKey: username
      remoteRef: { key: detectify/registry, property: username }
    - secretKey: password
      remoteRef: { key: detectify/registry, property: password }
```

#### Option 3: sealed-secrets

```bash
kubectl create secret generic my-team-scanner-config \
  -n scanner \
  --from-literal=license-key="..." \
  --from-literal=connector-api-key="..." \
  --from-literal=connector-url="https://connector.detectify.com" \
  --dry-run=client -o yaml \
  | kubeseal -o yaml > sealed-scanner-config.yaml

kubectl apply -f sealed-scanner-config.yaml
```

Repeat for the registry Secret, then set `secrets.existingConfigSecret` / `secrets.existingRegistrySecret` in your values file.

### Ingress Configuration

Enable ingress to expose the scanner API for triggering scans from CI/CD pipelines or external systems.

#### NGINX Ingress Controller

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
  host: scanner.example.com
  tls:
    enabled: true
    secretName: scanner-tls  # Pre-existing secret or cert-manager managed
```

## Security Hardening

As of 2.3.0 the chart ships secure-by-default hardening. Safe defaults are enabled out of the
box; settings that depend on your environment are off by default and can be enabled when you're
ready.

| Setting | Default | Effect |
|---------|---------|--------|
| `securityContext.enabled` | `true` | Runs all static pods non-root with a read-only root FS, no privilege escalation, all capabilities dropped, `seccompProfile: RuntimeDefault`. Set `false` to revert. |
| `networkPolicy.enabled` | `true` | Ingress-only NetworkPolicies restricting each component to its legitimate clients. Requires an enforcing CNI; inert otherwise. |
| `networkPolicy.strictApiIngress` | `false` | When `true`, locks scan-scheduler (3000) and scan-manager metrics (8080) to same-namespace ingress. Leave `false` if you scrape metrics or call the API from another namespace. |
| `limitRange.enabled` | `false` | Default requests/limits for the dynamic scan-worker / chrome pods. **Opt-in** — the default limit can OOM-kill or throttle large scans that previously ran unbounded; size the defaults for your load first. |
| `config.schedulerNeedsApi` | `true` | When `false`, drops the scan-scheduler ServiceAccount token (only needed for optional log retrieval). |
| `resourceQuota.enabled` | `false` | Hard namespace caps. **Opt-in** — size for your peak concurrent scans first; an undersized quota blocks scans. |
| `redis.auth.enabled` | `false` | **Opt-in** — enables Redis `requirepass` and threads the password into every consumer. Only for the bundled Redis. |

Redis (always) and scan-scheduler (when `config.schedulerNeedsApi: false`) run with
`automountServiceAccountToken: false`. The chrome-controller Role keeps `create`/`delete` on
`services` because it creates and deletes a Service per Chrome pod — this is the minimum
required.

See the **Security Hardening** guide in the Detectify documentation
(Internal Network Testing → Deploy → Helm → Security Hardening) for the full
shared-responsibility breakdown and sizing guidance.

## Operations

### Upgrading

```bash
helm repo update
helm upgrade scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner
```

When upgrading to 2.3.0 from an earlier version with a persistent Redis, a `pre-upgrade` hook
automatically re-owns the Redis data volume for the new non-root pod, so the upgrade works on any
storage backend with no manual step. This is skipped if your tooling doesn't run Helm hooks
(`--no-hooks`, some GitOps controllers) — see [UPGRADE.md](UPGRADE.md) for the manual fallback.

### Uninstalling

```bash
helm uninstall scanner -n scanner

# Optional: Remove the namespace and PVCs
kubectl delete namespace scanner
```

### Viewing Logs

```bash
# All components
kubectl logs -n scanner -l app.kubernetes.io/instance=scanner

# Specific component
kubectl logs -n scanner -l app.kubernetes.io/component=scan-scheduler
kubectl logs -n scanner -l app.kubernetes.io/component=scan-manager
kubectl logs -n scanner -l app.kubernetes.io/component=chrome-controller
```

## Troubleshooting

### Pods stuck in ImagePullBackOff

Verify registry credentials:

```bash
# Check the secret exists
kubectl get secret -n scanner detectify-registry -o yaml

# Verify credentials work
kubectl run test-pull --rm -it --restart=Never \
  --image=registry.detectify.com/internal-scanning/scan-scheduler:stable \
  --overrides='{"spec":{"imagePullSecrets":[{"name":"detectify-registry"}]}}'
```

### Redis PVC pending

Verify storage class availability:

```bash
kubectl get storageclass
kubectl describe pvc -n scanner

# Specify a storage class if default is not set
# redis.persistence.storageClass: "your-storage-class"
```

## Support

- **Documentation**: [Detectify Docs](https://docs.detectify.com)
- **Support Portal**: [Detectify Support](https://support.detectify.com)

## License

Copyright Detectify AB. See [LICENSE](LICENSE) for details.
