{{- define "internal-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "internal-scanner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "internal-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "internal-scanner.labels" -}}
helm.sh/chart: {{ include "internal-scanner.chart" . }}
{{ include "internal-scanner.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "internal-scanner.selectorLabels" -}}
app.kubernetes.io/name: {{ include "internal-scanner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "internal-scanner.scanSchedulerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanScheduler.repository .Values.images.scanScheduler.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanScheduler.repository .Values.images.scanScheduler.tag }}
{{- end }}
{{- end }}

{{- define "internal-scanner.scanManagerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanManager.repository .Values.images.scanManager.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanManager.repository .Values.images.scanManager.tag }}
{{- end }}
{{- end }}

{{- define "internal-scanner.scanWorkerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanWorker.repository .Values.images.scanWorker.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanWorker.repository .Values.images.scanWorker.tag }}
{{- end }}
{{- end }}

{{/* Redis uses Docker Hub (no registry prefix) */}}
{{- define "internal-scanner.redisImage" -}}
{{- printf "%s:%s" .Values.images.redis.repository .Values.images.redis.tag }}
{{- end }}

{{/* Name of the Secret holding license/connector credentials.
     Resolves to the customer-supplied Secret when `secrets.existingConfigSecret` is set,
     otherwise to the chart-managed `scanner-config`. */}}
{{- define "internal-scanner.configSecretName" -}}
{{- default "scanner-config" .Values.secrets.existingConfigSecret }}
{{- end }}

{{/* Name of the docker-registry Secret used for imagePullSecrets.
     Resolves to the customer-supplied Secret when `secrets.existingRegistrySecret` is set,
     otherwise to the chart-managed `detectify-registry`. */}}
{{- define "internal-scanner.registrySecretName" -}}
{{- default "detectify-registry" .Values.secrets.existingRegistrySecret }}
{{- end }}

{{/* Pod-level securityContext body. Guard the call site with `if .Values.securityContext.enabled`.
     Use as: securityContext: {{ include "internal-scanner.podSecurityContext" . | nindent 8 }} */}}
{{- define "internal-scanner.podSecurityContext" -}}
{{- toYaml .Values.securityContext.pod -}}
{{- end }}

{{/* Container-level securityContext body. Guard the call site with `if .Values.securityContext.enabled`.
     Use as: securityContext: {{ include "internal-scanner.containerSecurityContext" . | nindent 10 }} */}}
{{- define "internal-scanner.containerSecurityContext" -}}
{{- toYaml .Values.securityContext.container -}}
{{- end }}

{{/* Redis connection URL for app consumers. When `redis.auth.enabled` and the configured URL
     carries no inline credentials, inject the password via the Kubernetes `$(VAR)` env
     interpolation of REDIS_PASSWORD (which the deployments source from the config Secret). */}}
{{- define "internal-scanner.redisUrl" -}}
{{- $url := .Values.config.redisUrl -}}
{{- if and .Values.redis.auth.enabled (not (contains "@" $url)) -}}
{{- $url = $url | replace "://" "://:$(REDIS_PASSWORD)@" -}}
{{- end -}}
{{- $url -}}
{{- end }}

{{/* The REDIS_PASSWORD env entry sourced from the config Secret, rendered only when
     `redis.auth.enabled`. Must precede the REDIS_URL env var so `$(REDIS_PASSWORD)`
     interpolation resolves. Use with `nindent` at the env-list item indent. */}}
{{- define "internal-scanner.redisPasswordEnv" -}}
{{- if .Values.redis.auth.enabled }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "internal-scanner.configSecretName" . }}
      key: redis-password
{{- end }}
{{- end }}

{{/* Pre-install validations. Invoked from every resource template so the
     chart fails loudly during `helm install/upgrade/template` before
     rendering, rather than relying on NOTES.txt (which some tooling
     renders last or skips). */}}
{{- define "internal-scanner.validate" -}}
{{- if eq .Release.Namespace "default" -}}
{{- fail "internal-scanning-agent refuses to install into the `default` namespace. Pass `-n <namespace> --create-namespace` to helm install/upgrade. See UPGRADE.md for the 1.x → 2.0 migration notes." -}}
{{- end -}}
{{- if not .Values.secrets.existingConfigSecret -}}
{{- if not .Values.secrets.licenseKey -}}
{{- fail "secrets.licenseKey is required unless secrets.existingConfigSecret is set. See README.md (Bring-your-own Secret)." -}}
{{- end -}}
{{- if not .Values.secrets.connectorApiKey -}}
{{- fail "secrets.connectorApiKey is required unless secrets.existingConfigSecret is set. See README.md (Bring-your-own Secret)." -}}
{{- end -}}
{{- end -}}
{{- if not .Values.secrets.existingRegistrySecret -}}
{{- if not .Values.secrets.registry.username -}}
{{- fail "secrets.registry.username is required unless secrets.existingRegistrySecret is set. See README.md (Bring-your-own Secret)." -}}
{{- end -}}
{{- if not .Values.secrets.registry.password -}}
{{- fail "secrets.registry.password is required unless secrets.existingRegistrySecret is set. See README.md (Bring-your-own Secret)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
