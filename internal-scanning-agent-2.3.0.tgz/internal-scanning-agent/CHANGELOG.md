# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.3.0]

### Added

- `metrics.optOutAssessments`, `metrics.optOutCrawledURLs`, `metrics.optOutScreenShots`,
  `metrics.optOutLogs` — opt out of sending the respective scan metadata to Detectify.
- **Pod/container hardening** (`securityContext.enabled`, default on) on all four static
  deployments and the `wait-for-redis` init containers: runs non-root with a read-only root
  filesystem, no privilege escalation, all Linux capabilities dropped, and
  `seccompProfile: RuntimeDefault`. A writable `/tmp` volume is provided for runtime needs. Set
  `securityContext.enabled: false` to revert. Upgrading an existing persistent Redis is handled
  automatically — a `pre-upgrade` hook adjusts the data volume ownership for the non-root pod.
- **NetworkPolicies** (`networkPolicy.enabled`, default on, ingress-only) restricting inbound
  traffic to Redis (6379), scan-scheduler (3000), scan-manager metrics (8080), chrome-controller
  (8080) and chrome DevTools (9222) to their legitimate clients. Requires a CNI that enforces
  NetworkPolicy. `networkPolicy.strictApiIngress` (default off) additionally locks
  scheduler/manager ingress to the same namespace.
- **`automountServiceAccountToken: false`** on Redis. scan-scheduler token mounting is gated by
  `config.schedulerNeedsApi` (default on; set off to drop the token when scheduler log endpoints
  are unused).
- **`LimitRange`** (`limitRange.enabled`, default off) supplying default requests/limits to the
  dynamically created scan-worker and chrome pods. Off by default because the injected default
  limit can constrain large scans that previously ran unbounded; size and enable it for your load.
- **`ResourceQuota`** (`resourceQuota.enabled`, default off) for namespace-level resource caps.
- **Optional Redis authentication** (`redis.auth.enabled`, default off): enables Redis
  `requirepass` and injects the password into every consumer's `REDIS_URL`. The password is
  auto-generated and preserved across upgrades, or supply `redis.auth.password` /
  a `redis-password` key in an `existingConfigSecret`.

See the Security Hardening guide in the Detectify documentation for configuring the opt-in
settings (Redis authentication, `LimitRange`, `ResourceQuota`, strict API ingress, scheduler
token removal).

## [2.2.0] - 2026-05-13

### Added

- **HashiCorp Vault integration** (`hashicorp_vault.*`) as the secret backend for recorded-login
  credentials, including a bundled dev-mode Vault, Kubernetes auth, and `caCertConfigMap` for
  mounting a CA certificate into scan-worker pods.
- Conditional NodePort support for the scan-scheduler Service (`service.type: NodePort`,
  `service.nodePort`).

## [2.1.0] - 2026-05-04

### Added

- Support for fetching recorded-login secrets from Kubernetes Secrets: a dedicated `scan-worker`
  ServiceAccount with read access to Secrets, and the same grant for `scan-manager`.

## [2.0.0] - 2026-04-23

### Changed

- **BREAKING** Install namespace now follows `.Release.Namespace`. Pass `-n <namespace>` to `helm install/upgrade`; the chart refuses to install into `default`.
- **BREAKING** All sensitive inputs moved under a single top-level `secrets:` block:
  - `secrets.licenseKey` (was `config.licenseKey`)
  - `secrets.connectorApiKey` (was `config.connectorApiKey`)
  - `secrets.registry.username` (was `registry.username`)
  - `secrets.registry.password` (was `registry.password`)

### Added

- `secrets.existingConfigSecret` / `secrets.existingRegistrySecret` — point the chart at Kubernetes Secrets you manage outside Helm (Vault, external-secrets-operator, sealed-secrets, AWS Secrets Manager, ...). When set, the chart skips rendering `scanner-config` / `detectify-registry`.
- Credential-presence validation at install time — `helm install/upgrade` fails with a clear message if required `secrets.*` fields are missing and no `existing*Secret` is set.
- `UPGRADE.md` with 1.x → 2.0 migration snippets for every renamed/removed field.
- README sections with worked BYO-Secret examples for `kubectl`, external-secrets-operator, and sealed-secrets.

### Removed

- **BREAKING** `namespace.name` value (use `helm -n`).
- **BREAKING** `config.licenseKey`, `config.connectorApiKey` (moved under `secrets.*`).
- **BREAKING** `config.imagePullSecret` (chart now derives it from the registry Secret name).
- **BREAKING** `registry.imagePullSecrets` (chart now wires the registry Secret automatically).

## [1.3.0] - 2026-03-09

### Fixed

- Use correct image tag for Chrome Container

### Removed

- Unused option
- Removed `config.scannerNamespace` (use `namespace.name` instead)

## [1.2.0] - 2026-03-05

### Fixed

- Simplify setup by setting working default values for:
  - `registry.server`
  - `registry.imagePullSecrets`
  - `images.*.tag`
- Adjust resource requirements.
- Changed default `minReplicas` to `1` for `scanScheduler`.

### Removed

- Removed Prometheus and related options

## [1.1.0] - 2026-02-17

### Added
- Redis persistence with PVC, volumeMounts, and `redis.deploy` toggle
- `Recreate` deployment strategy for Redis when persistence is enabled (prevents RWO PVC deadlock)
- `wait-for-redis` init containers on scan-scheduler and scan-manager
- PriorityClass for redis and scan-scheduler to protect critical components under resource pressure

### Fixed
- Autoscaling config keys not applied to Helm chart

## [1.0.0] - 2025-02-03

### Added
- Initial release of Detectify Internal Scanning Helm Chart
- scan-scheduler: API entry point, license validation, job queuing
- scan-manager: Job orchestration, scan-worker pod management
- scan-worker: Ephemeral pods for security scanning
- chrome-controller: Browser instance management
- Redis: Persistent job queue with optional external Redis support
- Horizontal Pod Autoscaling (HPA) for scan-scheduler and scan-manager
- Prometheus metrics and Pushgateway integration
- Configurable resource limits and requests
- Support for Kubernetes 1.24+

[Unreleased]: https://github.com/detectify/helm-charts/compare/v2.3.0...HEAD
[2.3.0]: https://github.com/detectify/helm-charts/compare/v2.2.0...v2.3.0
[2.2.0]: https://github.com/detectify/helm-charts/compare/v2.1.0...v2.2.0
[2.1.0]: https://github.com/detectify/helm-charts/compare/v2.0.0...v2.1.0
[2.0.0]: https://github.com/detectify/helm-charts/compare/v1.3.0...v2.0.0
[1.3.0]: https://github.com/detectify/helm-charts/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/detectify/helm-charts/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/detectify/helm-charts/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/detectify/helm-charts/releases/tag/v1.0.0
