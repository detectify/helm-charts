# Upgrade Guide

## 2.x → 2.3.0

Version 2.3.0 adds secure-by-default hardening. Safe defaults are enabled automatically and
environment-dependent settings stay off until you opt in, so upgrading requires no values
changes. There is one storage-dependent caveat to be aware of.

### Redis persistent volume + non-root pod (handled automatically)

Pod hardening (`securityContext.enabled: true`, on by default) runs Redis as UID/GID `1000`. On a
**persistent** Redis (`redis.persistence.enabled: true`, the default), the data files already on
the volume were written by the previous root Redis user. Kubernetes normally re-owns the volume
via `fsGroup` on mount, but **some storage backends (hostPath, local-path, certain NFS/CSI
drivers) do not apply `fsGroup`** — there Redis would otherwise CrashLoop with `Can't open the
append-only file ... Permission denied`.

**You don't need to do anything for this.** The chart runs a `pre-upgrade` hook Job that chowns
the volume to `1000:1000` before the new Redis rolls out, so the upgrade is storage-independent.
The Job only runs on upgrade (not first install) and only when both persistence and
`securityContext` are enabled; it is a no-op on backends that already apply `fsGroup`.

If your tooling does not run Helm hooks, the auto-fix Job won't fire. This applies to:

- `helm upgrade --no-hooks`;
- **GitOps controllers** — Argo CD and Flux render the chart and apply manifests themselves
  rather than running `helm upgrade`, and translate Helm hooks into their own sync-hook
  semantics. Argo CD maps `helm.sh/hook: pre-upgrade` to a `PreSync` hook **only if** hook
  rendering is enabled; Flux runs chart hooks only when `.spec.install.crds` / hook execution is
  configured. If hooks are disabled or unmapped in your pipeline, the Job is skipped.

In those cases, on a storage backend that doesn't apply `fsGroup`, Redis will CrashLoop after the
upgrade. Fix it manually once with `chown -R 1000:1000 /data` (see the Security Hardening guide)
and re-sync, or set `securityContext.enabled: false` to revert pod hardening.

Ephemeral Redis (`redis.persistence.enabled: false`) is unaffected — it starts clean each time.

### Opt-in hardening

Redis authentication, namespace `ResourceQuota`, strict API ingress, and dropping the
scan-scheduler token are all off by default. See the **Security Hardening** guide in the
Detectify documentation for how and when to enable each.

## 1.x → 2.0.0

Version 2.0.0 restructures the chart to address three long-standing requests:

1. The deployment namespace is now driven by `--namespace` / `-n` at install time (no `values` override needed).
2. All sensitive inputs live under a single `secrets:` block.
3. You can bring your own Kubernetes Secrets (Vault, external-secrets-operator, sealed-secrets, AWS Secrets Manager, ...) instead of letting Helm create them.

This is a breaking change for every existing installation. Follow the migration steps below.

### Breaking changes

#### 1. `namespace.name` removed

The chart no longer reads `namespace.name` from values. Every resource now targets `.Release.Namespace`.

**Before (1.x)**

```yaml
namespace:
  name: scanner
```

**After (2.0.0)**

```yaml
# (removed — pass -n on the CLI)
```

```bash
helm install scanner detectify/internal-scanning-agent -n scanner --create-namespace ...
```

#### 2. Credentials moved to `secrets:`

Sensitive values no longer live under `registry:` or `config:`. They now sit under a single `secrets:` block.

**Before (1.x)**

```yaml
registry:
  username: "your-registry-username"
  password: "your-registry-password"

config:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
```

**After (2.0.0)**

```yaml
secrets:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
  registry:
    username: "your-registry-username"
    password: "your-registry-password"
```

Non-secret URLs (`connectorServerUrl`, `licenseServerUrl`, `redisUrl`, polling intervals, `logFormat`, ...) stay under `config:`. Registry image paths (`registry.server`, `registry.url`) stay under `registry:`.

#### 3. `config.imagePullSecret` removed

It was always driven by the registry Secret; the chart now derives it internally from the Secret name. Remove it from your values.

#### 4. `registry.imagePullSecrets` no longer used

The chart resolves `imagePullSecrets` automatically from `secrets.existingRegistrySecret` (or the chart-managed `detectify-registry`). Remove any override.

### New features

#### Bring-your-own Secret

Point the chart at Secrets you manage outside Helm.

```yaml
secrets:
  existingConfigSecret: "my-team-scanner-config"
  existingRegistrySecret: "my-team-detectify-registry"
```

Expected schemas:

- `existingConfigSecret` (type `Opaque`) — keys:
    - `license-key`
    - `connector-api-key`
    - `connector-url`
- `existingRegistrySecret` (type `kubernetes.io/dockerconfigjson`) — standard `.dockerconfigjson` key.

When `existingConfigSecret` is set, the chart does **not** render `scanner-config` and the pods read from your Secret. The same applies to `existingRegistrySecret` and `detectify-registry`.

### Migration steps

1. Rewrite `values.yaml` using the before/after snippets above.
2. Drop `namespace.name` and remove any `config.imagePullSecret` / `registry.imagePullSecrets` overrides.
3. Upgrade:

    ```bash
    helm upgrade scanner detectify/internal-scanning-agent \
      -f my-values.yaml \
      -n scanner
    ```

4. If moving to bring-your-own Secrets, create the Secrets first, then set `secrets.existingConfigSecret` / `secrets.existingRegistrySecret` and re-run `helm upgrade`. Helm removes the previously chart-managed `scanner-config` / `detectify-registry` Secrets automatically on the next release — no manual cleanup required.

### Complete example

```yaml
secrets:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
  registry:
    username: "your-registry-username"
    password: "your-registry-password"

ingress:
  enabled: true
  className: nginx
  host: scanner.example.com
  tls:
    enabled: true
    secretName: scanner-tls
```

```bash
helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace
```
