# Release Notes Template

This file is used by the CI/CD pipeline to generate GitHub Release content.

## Installation

```bash
helm repo add detectify https://detectify.github.io/helm-charts
helm repo update
helm install scanner detectify/internal-scanning-agent --version ${VERSION} \
  --namespace scanner --create-namespace \
  -f values.yaml
```

## Quick Start

Create a `values.yaml` with your credentials:

```yaml
registry:
  server: registry.detectify.com
  username: "your-registry-username"
  password: "your-registry-password"

config:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
```

## Documentation

See the [README](https://github.com/detectify/helm-charts/blob/gh-pages/README.md) for full documentation and all available values.
