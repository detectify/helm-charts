# Detectify Internal Scanning Agent

Helm chart for deploying [Detectify Internal Scanning Agent](https://detectify.com/product/internal-scanning) to your Kubernetes cluster.

## Quick Start

```bash
# Add the Detectify Helm repository
helm repo add detectify https://detectify.github.io/helm-charts
helm repo update

# Create a values file with your credentials
cat > my-values.yaml <<EOF
registry:
  server: registry.detectify.com
  username: "your-registry-username"
  password: "your-registry-password"

config:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
EOF

# Install the chart
helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace

# Verify the deployment
kubectl get pods -n scanner
```

## Prerequisites

- Kubernetes 1.24+
- Helm 3.8+
- Detectify license credentials (contact [Detectify Sales](https://detectify.com/contact))
- PersistentVolume provisioner (for Redis storage)

### Network Requirements

The scanner requires outbound HTTPS (443) access to:

| Endpoint | Purpose |
|----------|---------|
| `registry.detectify.com` | Pull container images |
| `license.detectify.com` | License validation |
| `connector.detectify.com` | Scan coordination with Detectify platform |

Ensure these endpoints are accessible from your cluster. No inbound connections are required unless you enable ingress for the API.

## Components

| Component | Description |
|-----------|-------------|
| **Scan Scheduler** | API endpoint for triggering scans, validates licenses, queues jobs |
| **Scan Manager** | Orchestrates scan execution, creates ephemeral scan-worker pods |
| **Scan Worker** | Ephemeral pods that execute security tests against targets |
| **Chrome Controller** | Manages pool of headless Chrome instances for JavaScript analysis |
| **Redis** | Persistent queue for scan jobs and state management |

## Installation

### From Helm Repository (Recommended)

```bash
helm repo add detectify https://detectify.github.io/helm-charts
helm repo update

helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace
```

## Configuration

### Required Values

These values must be provided for the scanner to function:

```yaml
registry:
  username: "your-registry-username"   # Provided by Detectify
  password: "your-registry-password"   # Provided by Detectify

config:
  licenseKey: "your-license-key"       # Provided by Detectify
  connectorApiKey: "your-connector-api-key"  # Provided by Detectify
```

### Ingress Configuration

Enable ingress to expose the scanner API for triggering scans from CI/CD pipelines or external systems.

#### NGINX Ingress Controller

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
  host: scanner.example.com
  tls:
    enabled: true
    secretName: scanner-tls  # Pre-existing secret or cert-manager managed
```

## Operations

### Upgrading

```bash
helm repo update
helm upgrade scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner
```

### Uninstalling

```bash
helm uninstall scanner -n scanner

# Optional: Remove the namespace and PVCs
kubectl delete namespace scanner
```

### Viewing Logs

```bash
# All components
kubectl logs -n scanner -l app.kubernetes.io/instance=scanner

# Specific component
kubectl logs -n scanner -l app.kubernetes.io/component=scan-scheduler
kubectl logs -n scanner -l app.kubernetes.io/component=scan-manager
kubectl logs -n scanner -l app.kubernetes.io/component=chrome-controller
```

## Troubleshooting

### Pods stuck in ImagePullBackOff

Verify registry credentials:

```bash
# Check the secret exists
kubectl get secret -n scanner detectify-registry -o yaml

# Verify credentials work
kubectl run test-pull --rm -it --restart=Never \
  --image=registry.detectify.com/internal-scanning/scan-scheduler:stable \
  --overrides='{"spec":{"imagePullSecrets":[{"name":"detectify-registry"}]}}'
```

### Redis PVC pending

Verify storage class availability:

```bash
kubectl get storageclass
kubectl describe pvc -n scanner

# Specify a storage class if default is not set
# redis.persistence.storageClass: "your-storage-class"
```

## Support

- **Documentation**: [Detectify Docs](https://docs.detectify.com)
- **Support Portal**: [Detectify Support](https://support.detectify.com)

## License

Copyright Detectify AB. See [LICENSE](LICENSE) for details.
