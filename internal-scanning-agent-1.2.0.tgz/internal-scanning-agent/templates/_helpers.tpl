{{- define "internal-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "internal-scanner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "internal-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "internal-scanner.labels" -}}
helm.sh/chart: {{ include "internal-scanner.chart" . }}
{{ include "internal-scanner.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "internal-scanner.selectorLabels" -}}
app.kubernetes.io/name: {{ include "internal-scanner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "internal-scanner.scanSchedulerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanScheduler.repository .Values.images.scanScheduler.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanScheduler.repository .Values.images.scanScheduler.tag }}
{{- end }}
{{- end }}

{{- define "internal-scanner.scanManagerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanManager.repository .Values.images.scanManager.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanManager.repository .Values.images.scanManager.tag }}
{{- end }}
{{- end }}

{{- define "internal-scanner.scanWorkerImage" -}}
{{- if .Values.registry.url }}
{{- printf "%s/%s:%s" .Values.registry.url .Values.images.scanWorker.repository .Values.images.scanWorker.tag }}
{{- else }}
{{- printf "%s:%s" .Values.images.scanWorker.repository .Values.images.scanWorker.tag }}
{{- end }}
{{- end }}

{{/* Redis uses Docker Hub (no registry prefix) */}}
{{- define "internal-scanner.redisImage" -}}
{{- printf "%s:%s" .Values.images.redis.repository .Values.images.redis.tag }}
{{- end }}
