# Upgrade Guide

## 1.x → 2.0.0

Version 2.0.0 restructures the chart to address three long-standing requests:

1. The deployment namespace is now driven by `--namespace` / `-n` at install time (no `values` override needed).
2. All sensitive inputs live under a single `secrets:` block.
3. You can bring your own Kubernetes Secrets (Vault, external-secrets-operator, sealed-secrets, AWS Secrets Manager, ...) instead of letting Helm create them.

This is a breaking change for every existing installation. Follow the migration steps below.

### Breaking changes

#### 1. `namespace.name` removed

The chart no longer reads `namespace.name` from values. Every resource now targets `.Release.Namespace`.

**Before (1.x)**

```yaml
namespace:
  name: scanner
```

**After (2.0.0)**

```yaml
# (removed — pass -n on the CLI)
```

```bash
helm install scanner detectify/internal-scanning-agent -n scanner --create-namespace ...
```

#### 2. Credentials moved to `secrets:`

Sensitive values no longer live under `registry:` or `config:`. They now sit under a single `secrets:` block.

**Before (1.x)**

```yaml
registry:
  username: "your-registry-username"
  password: "your-registry-password"

config:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
```

**After (2.0.0)**

```yaml
secrets:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
  registry:
    username: "your-registry-username"
    password: "your-registry-password"
```

Non-secret URLs (`connectorServerUrl`, `licenseServerUrl`, `redisUrl`, polling intervals, `logFormat`, ...) stay under `config:`. Registry image paths (`registry.server`, `registry.url`) stay under `registry:`.

#### 3. `config.imagePullSecret` removed

It was always driven by the registry Secret; the chart now derives it internally from the Secret name. Remove it from your values.

#### 4. `registry.imagePullSecrets` no longer used

The chart resolves `imagePullSecrets` automatically from `secrets.existingRegistrySecret` (or the chart-managed `detectify-registry`). Remove any override.

### New features

#### Bring-your-own Secret

Point the chart at Secrets you manage outside Helm.

```yaml
secrets:
  existingConfigSecret: "my-team-scanner-config"
  existingRegistrySecret: "my-team-detectify-registry"
```

Expected schemas:

- `existingConfigSecret` (type `Opaque`) — keys:
    - `license-key`
    - `connector-api-key`
    - `connector-url`
- `existingRegistrySecret` (type `kubernetes.io/dockerconfigjson`) — standard `.dockerconfigjson` key.

When `existingConfigSecret` is set, the chart does **not** render `scanner-config` and the pods read from your Secret. The same applies to `existingRegistrySecret` and `detectify-registry`.

### Migration steps

1. Rewrite `values.yaml` using the before/after snippets above.
2. Drop `namespace.name` and remove any `config.imagePullSecret` / `registry.imagePullSecrets` overrides.
3. Upgrade:

    ```bash
    helm upgrade scanner detectify/internal-scanning-agent \
      -f my-values.yaml \
      -n scanner
    ```

4. If moving to bring-your-own Secrets, create the Secrets first, then set `secrets.existingConfigSecret` / `secrets.existingRegistrySecret` and re-run `helm upgrade`. Helm removes the previously chart-managed `scanner-config` / `detectify-registry` Secrets automatically on the next release — no manual cleanup required.

### Complete example

```yaml
secrets:
  licenseKey: "your-license-key"
  connectorApiKey: "your-connector-api-key"
  registry:
    username: "your-registry-username"
    password: "your-registry-password"

ingress:
  enabled: true
  className: nginx
  host: scanner.example.com
  tls:
    enabled: true
    secretName: scanner-tls
```

```bash
helm install scanner detectify/internal-scanning-agent \
  -f my-values.yaml \
  -n scanner \
  --create-namespace
```
